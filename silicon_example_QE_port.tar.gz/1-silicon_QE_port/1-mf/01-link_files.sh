#!/bin/bash -l

# This serial script links the WFN files from the MF to the BGW folder.

# First, link all CD files
echo "Linking pseudopotential and charge densities"
for directory in {2,3,4}*-*/; do
  echo " Working on directory $directory"
  cd $directory
  mkdir silicon.save
  ln -sf ../../1-scf/silicon.save/charge-density.dat silicon.save/
  ln -sf ../../1-scf/silicon.save/data-file.xml silicon.save/
  ln -sf ../1-scf/Si.UPF .
  cd ../
done
echo

echo "Linking WFNs to BGW directory"
cd ../2-bgw/

echo " Working on directory 1-epsilon"
cd 1-epsilon/
ln -sf ../../1-mf/2.1-wfn/wfn.real WFN
ln -sf ../../1-mf/2.2-wfnq/wfn.real WFNq
cd ../

echo " Working on directory 2-sigma"
cd 2-sigma/
ln -sf ../../1-mf/2.1-wfn/rho.real ./RHO
ln -sf ../../1-mf/2.1-wfn/wfn.real WFN_inner
ln -sf ../../1-mf/2.1-wfn/vxc.dat .
cd bandstructure/
ln -sf ../../../1-mf/2.1-wfn/wfn.real WFN_co
ln -sf ../../../1-mf/4-bandstructure/wfn.real WFN_fi
cd ..
cd ..

echo " Working on directory 3-kernel"
cd 3-kernel/
ln -sf ../../1-mf/2.1-wfn/wfn.real WFN_co
cd ../

echo " Working on directory 4-absorption"
cd 4-absorption/
ln -sf ../../1-mf/2.1-wfn/wfn.real WFN_co
ln -sf ../../1-mf/3.1-wfn_fi/wfn.real WFN_fi
ln -sf ../../1-mf/3.2-wfnq_fi/wfn.real WFNq_fi
cd ../

echo
echo "Done!"
